# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import wepelo_equipment_customer
from . import wepelo_equipment_system
from . import wepelo_maintenance
from . import mail_activity
from . import wepelo_equipment_protocol
from . import wepelo_repair
from . import qr_code
from . import wepelo_customer
from . import wepelo_history
from . import res_users
from . import ir_attachment

